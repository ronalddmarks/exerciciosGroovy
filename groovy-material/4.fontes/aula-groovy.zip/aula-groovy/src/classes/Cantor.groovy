package classes

public interface Cantor {
    void cantar()
}

