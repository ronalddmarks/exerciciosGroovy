package classes

import groovy.transform.builder.Builder

@Builder
class Comida {
	String fruta
	String bebida
	String doce
}


