package classes

import groovy.transform.ToString

@ToString
class Comissao {
    BigDecimal valor
    BigDecimal comissao
}

