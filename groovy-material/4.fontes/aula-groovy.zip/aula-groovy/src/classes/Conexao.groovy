package classes

@Singleton
class Conexao {
    Double valor
}

