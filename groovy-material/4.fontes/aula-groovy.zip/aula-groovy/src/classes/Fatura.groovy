package classes

class Fatura {
}

