package classes

import groovy.transform.EqualsAndHashCode

@EqualsAndHashCode
class Funcionario2 {
    String nome
    Integer idade
    Double salario
}

