package classes

class Ola {
    // Exercicio 1
    //  void = n�o colocou nada no retorno vira def = object = generico = qualquer coisa
    static main(args) {
        println "ola mundo java"
    }
}