package classes

class Palco {    
    void show(Cantor c) {
        c.cantar()
    }
}

