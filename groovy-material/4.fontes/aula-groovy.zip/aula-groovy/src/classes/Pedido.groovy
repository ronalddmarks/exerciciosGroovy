package classes

import groovy.transform.Immutable

@Immutable
class Pedido {
    String cliente
    Integer numero
}

