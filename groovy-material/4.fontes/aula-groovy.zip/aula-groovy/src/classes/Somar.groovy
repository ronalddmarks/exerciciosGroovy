package classes

class Somar {
    double somar(double[] valores) {
        double rs = 0;
        for (double v:  valores) {
            rs += v;
        }
        rs
    }
}

