package classes

class Teste {
    def metodo(valor) {
         valor + 1
    }
}

