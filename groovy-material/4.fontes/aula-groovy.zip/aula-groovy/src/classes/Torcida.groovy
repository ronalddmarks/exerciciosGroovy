package classes

public interface Torcida {
    void pular();
    void gritar(String texto)
}


