package classes

class Venda {
      double vender(double valor, int taxa = 10) {
           double rs = valor * taxa / 100
           rs // s� para lembrar do return como ultima linha.
      }
}

